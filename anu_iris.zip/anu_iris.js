const anu_iris = async (scene, dataStr) => {
    //assuming the data is loaded as string
    let anuData = JSON.parse(dataStr[0]);
    console.log("anuData: " + dataStr[0]);
    var scaleX = d3.scaleLinear().domain(d3.extent(d3.map(anuData, (d) => { return d.sepalLength }))).range([-10, 10]).nice();
    var scaleY = d3.scaleLinear().domain(d3.extent(d3.map(anuData, (d) => { return d.petalLength }))).range([-10, 10]).nice();
    var scaleZ = d3.scaleLinear().domain(d3.extent(d3.map(anuData, (d) => { return d.sepalWidth }))).range([-10, 10]).nice();

    //This is a function that will create a color scale for our three types of flowers in our data
    //pass in the flower name and it will return the hex of its color coding. d3.schemecategory10 is an array of 10 color hexes
    var scaleC = d3.scaleOrdinal().domain(['setosa', 'versicolor', 'virginica']).range(d3.schemeCategory10)

    //Create a transform node to use as the parent node for all our meshes
    let CoT = new BABYLON.TransformNode('cot');
    CoT.position = new BABYLON.Vector3(3.0, 1.5, 0.0);
    CoT.scaling = new BABYLON.Vector3(0.05, 0.05, 0.05);
    let dataMaterial = new BABYLON.StandardMaterial("dataMaterial", scene);
    dataMaterial.diffuseColor = new BABYLON.Color3(.62, .514, .396);
    dataMaterial.specularColor = new BABYLON.Color3(93 / 255, 93 / 255, 93 / 255);
    //.prop('name', (d, i) => spherese.selected[i].metadata.data.sepalLength)
    //new StandardMaterial("myMaterial", this.scene))

    const grabber = new BABYLON.PointerDragBehavior({ dragAxis: new BABYLON.Vector3(1, 0, 0) });
    //grabber.moveAttached = false; // Disable moving the grabber itself
    // Listen to drag events
    grabber.onDragStartObservable.add((event) => {
        console.log("dragStart");
        console.log(event);
    })
    grabber.onDragObservable.add((event) => {
        console.log("drag");
        console.log(event);
        console.log(grabber.currentDraggingPointerID);
    })
    grabber.onDragEndObservable.add((event) => {
        console.log("dragEnd");
        console.log(event);
    })

    const grabberTest = new BABYLON.PointerDragBehavior({ dragAxis: new BABYLON.Vector3(1, 0, 0) });
    let assignBehavior = (mesh, behavior) => {
        mesh.addBehavior(behavior);
    }

    let spheres = anu.select('#cot', scene)
        //use select to pick a node by #name, this will create a selection object which contains a list of every node in the selection and the scene
        .bind('sphere', { diameter: 0.5 }, anuData)
        // .props({'position.x': (d) => scaleX(d.sepalLength),
        //         'position.y': (d) => scaleY(d.petalLength),
        //         'position.z': (d) => scaleZ(d.sepalWidth)
        //         })
        //pick a mesh, define any params (including passing functions), and select what data to use. For each row of the data, a sphere will be created as a child  of our selection 
        //with the data append to the mesh obj. Bind will return a new selection object with all of the meshes we just created 
        .positionX((d) => scaleX(d.sepalLength)) //most selection methods can either be passed a raw value, or a function that will return the correct value of the attribute
        .positionY((d) => scaleY(d.petalLength))  //When you pass a function the method will pass the data associated with the mesh as JSON and the index of the data (d,i)
        .positionZ((d) => scaleZ(d.sepalWidth)) //So we create a function that takes param d and since we know the keys of the data can pass d.<key> into our function that returns an int
        .material((d) => {
            let mat = new BABYLON.StandardMaterial('mat', scene);
            mat.specularColor = new BABYLON.Color3(93 / 255, 93 / 255, 93 / 255);
            return mat;
        }) //We need to create a material for our mesh before we can change its color
        .diffuseColor((d) => BABYLON.Color3.FromHexString(scaleC(d.species))) //change the diffuse color of our material using our color scale function.
        //Babylon use an action system to trigger events form interacting with meshes, this is a simple example to show a hover interaction. grow when hover and shrink when stopped. 
        .action((d) => new BABYLON.InterpolateValueAction(
            BABYLON.ActionManager.OnPointerOverTrigger,
            d,
            'scaling',
            new BABYLON.Vector3(1.2, 1.2, 1.2),
            100
        ))
        .action((d) => new BABYLON.InterpolateValueAction(
            BABYLON.ActionManager.OnPointerOutTrigger,
            d,
            'scaling',
            new BABYLON.Vector3(1, 1, 1),
            100))
        // .func((d:Mesh) => {
        //     handleCollabXRObj(d);
        // })
        .func((d) => assignBehavior(d, new BABYLON.PointerDragBehavior({ dragAxis: new BABYLON.Vector3(1, 0, 0) })));

    //axis is a special method in anu to create a axis with its origin at the selection. It takes a d3 scale function and a string to indicated which transform dimension (x,y,z)
    //TODO it doesn' work currently
    let axis = new anu.AxisAlt('testAxis', scene, {
        cot: anu.select('#cot', scene),
        x: scaleX, y: scaleY, z: scaleZ
    }).shape().background().label().ticks();
}

// Export the functions
module.exports = { anu_iris };
