const anu_yieldcurve = async (scene, dataStr) => {
    let CoT = new BABYLON.TransformNode('cotYieldCurve');
    //let data = await d3.csv(dataURL);
    let data = await d3.csvParse(dataStr[0]);
    var scaleY = d3.scaleLinear().domain([0, 9]).range([-2, 2]).nice()
    var scaleZ = d3.scaleLinear().domain([1, 6]).range([-3, 3]).nice();
    var scaleC = d3.scaleSequential(d3.interpolateBlues).domain([3, -3]);

    var parseTime = d3.timeParse("%m/%d/%Y");
    var dateFormat = d3.timeFormat("%y");
    var dates = [];
    for (let obj of data) {
        dates.push(parseTime(obj.Date));
    }

    var domain = d3.extent(dates);


    var scaleX = d3.scaleTime().domain(domain).range([-5, 5]);



    let myPaths = [];
    data.forEach((d, i) => {
        //console.log(scaleX(dates[i]))
        myPaths.push([
            new BABYLON.Vector3(scaleX(parseTime(d.Date)), scaleY(d["1 Yr"]), scaleZ(1)),
            new BABYLON.Vector3(scaleX(parseTime(d.Date)), scaleY(d["2 Yr"]), scaleZ(2)),
            new BABYLON.Vector3(scaleX(parseTime(d.Date)), scaleY(d["3 Yr"]), scaleZ(3)),
            new BABYLON.Vector3(scaleX(parseTime(d.Date)), scaleY(d["5 Yr"]), scaleZ(4)),
            new BABYLON.Vector3(scaleX(parseTime(d.Date)), scaleY(d["7 Yr"]), scaleZ(5)),
            new BABYLON.Vector3(scaleX(parseTime(d.Date)), scaleY(d["10 Yr"]), scaleZ(6)),
        ])
    });





    const options = {
        pathArray: myPaths, //[vector3 array, vector3 array, vector3 array......]
        updatable: true,
        sideOrientation: BABYLON.Mesh.DOUBLESIDE
    }

    let ribbon = BABYLON.MeshBuilder.CreateRibbon("ribbon", options, scene);




    var colors = ribbon.getVerticesData(BABYLON.VertexBuffer.ColorKind);
    if (!colors) {
        colors = [];

        var positions = ribbon.getVerticesData(BABYLON.VertexBuffer.PositionKind);

        for (var p = 0; p < positions.length; p += 3) {
            var color = scaleC(positions[p + 1]).substring(4, scaleC(positions[p + 1]).length - 1)
                .replace(/ /g, '').split(',')

            colors.push(color[0] / 225, color[1] / 225, color[2] / 225, 1);
        }
    }

    ribbon.setVerticesData(BABYLON.VertexBuffer.ColorKind, colors);
    ribbon.parent = CoT;

    let years = ["1 Yr", "2 Yr", "3 Yr", "5 Yr", "7 Yr", "10 Yr"]

    let axis = new anu.AxisAlt('testAxis', scene, { cot: anu.select('#cotYieldCurve', scene), x: scaleX, y: scaleY, z: scaleZ }).shape({ radius: 0.02 }, { 'material.diffuseColor': BABYLON.Color3.Black, 'material.alpha': 1, 'material.specularColor': BABYLON.Color3.Black }).background()
        .label({
            x: scaleX.ticks(d3.timeYear.every(2)),
            y: scaleY.ticks(),
            z: scaleZ.ticks(6)
        },
            {
                x: { text: (d) => { return dateFormat(d.text) } },
                y: { text: (d) => { if (d.text === undefined) { return "0%" } else { return d.text + '%' } } },
                z: { text: (d) => { return years[d.text - 1] } }
            })
        .ticks({
            x: scaleX.ticks(d3.timeYear.every(2)),
            y: scaleY.ticks(),
            z: scaleZ.ticks()
        });


    let grid = [];
    for (var i = 1; i <= 6; i++) {
        let temp = []
        console.log(years[i])
        data.forEach((d) => {
            temp.push(new BABYLON.Vector3(scaleX(parseTime(d.Date)), scaleY(d[years[i - 1]]), scaleZ(i)))
        });
        grid.push(temp)
    }

    var outline = [grid.shift(), grid.pop()]

    let tickMesh = anu.select('#cotYieldCurve', scene).bind('lineSystem', { lines: grid }).attr('color', new BABYLON.Color3(1, 1, 1)).prop('alpha', 0.5);

    let tickMesh2 = anu.select('#cotYieldCurve', scene).bind('lineSystem', { lines: outline }).attr('color', new BABYLON.Color3(0, 0, 0));

    CoT.scaling = new BABYLON.Vector3(0.1, 0.1, 0.1);
    CoT.position = new BABYLON.Vector3(0.0, 1.0, 0.0);

    CoT.scaling = new BABYLON.Vector3(0.2, 0.2, 0.2);
    CoT.position = new BABYLON.Vector3(-3.0, 1.0, 0.0);
}

// Export the functions
module.exports = { anu_yieldcurve };
